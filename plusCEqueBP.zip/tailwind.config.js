/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: 'var(--color-primary)',
        'primary-dark': 'var(--color-primary-dark)',
      },
      fontFamily: {
        ubuntu: ['Ubuntu', 'sans-serif'],
      },
      keyframes: {
        fadeIn: {
          from: { opacity: '0', transform: 'translateY(8px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        drawCircle: {
          from: { strokeDashoffset: '166' },
          to: { strokeDashoffset: '0' },
        },
        drawCheck: {
          from: { strokeDashoffset: '48' },
          to: { strokeDashoffset: '0' },
        },
      },
      animation: {
        fadeIn: 'fadeIn 0.35s ease-out forwards',
        drawCircle: 'drawCircle 0.6s ease-out forwards',
        drawCheck: 'drawCheck 0.3s 0.5s ease-out forwards',
      },
    },
  },
  plugins: [],
};
