import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { theme } from './config/theme';
import './index.css';

// Inject brand colors as CSS variables
document.documentElement.style.setProperty('--color-primary', theme.primary);
document.documentElement.style.setProperty('--color-primary-dark', theme.primaryDark);

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
