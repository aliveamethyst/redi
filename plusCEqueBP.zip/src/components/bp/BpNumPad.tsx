import { useState, useEffect, useCallback } from 'react';
import { theme } from '../../config/theme';

interface Props {
  length: number;
  value: string;
  onChange: (v: string) => void;
}

function shuffle(a: number[]) {
  const r = [...a];
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [r[i], r[j]] = [r[j], r[i]];
  }
  return r;
}

export default function BpNumPad({ length, value, onChange }: Props) {
  const [digits, setDigits] = useState<number[]>([]);

  useEffect(() => { setDigits(shuffle([0,1,2,3,4,5,6,7,8,9])); }, []);

  const press = useCallback((d: number) => {
    if (value.length < length) onChange(value + String(d));
  }, [value, length, onChange]);

  const row1 = digits.slice(0, 5);
  const row2 = digits.slice(5, 10);

  return (
    <div>
      <p className="text-[13px] font-medium text-gray-700 mb-3">Saisissez votre mot de passe</p>
      <div className="flex gap-[10px] justify-center mb-4">
        {Array.from({ length }).map((_, i) => (
          <div
            key={i}
            className="w-[20px] h-[20px] rounded-full border-2 transition-all duration-150"
            style={i < value.length
              ? { background: theme.primary, borderColor: theme.primary }
              : { background: 'white', borderColor: '#9ca3af' }
            }
          />
        ))}
      </div>
      <div className="space-y-[8px] mb-3">
        {[row1, row2].map((row, ri) => (
          <div key={ri} className="flex justify-center gap-[8px]">
            {row.map((d) => (
              <button
                key={`${ri}-${d}`}
                type="button"
                onClick={() => press(d)}
                className="w-[48px] h-[48px] flex items-center justify-center text-[17px] font-medium text-gray-900 bg-[#f5f5f5] hover:bg-[#e8e8e8] active:bg-[#ddd] border border-gray-300 rounded-lg transition-colors select-none cursor-pointer"
              >
                {d}
              </button>
            ))}
          </div>
        ))}
      </div>
      <button type="button" onClick={() => onChange('')} className="text-[13px] text-primary hover:underline font-medium mb-4 block cursor-pointer">
        Effacer
      </button>
    </div>
  );
}
