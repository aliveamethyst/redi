import { theme } from '../../config/theme';

export default function BpHeader() {
  return (
    <header className="bg-white fixed top-0 left-0 right-0 z-50 border-b border-gray-200">
      <div className="flex items-center justify-between px-4 md:px-8 h-[60px]">
        <a href="#" className="flex-shrink-0">
          <img src={theme.logo} alt="Banque Populaire" className="h-[36px] md:h-[42px]" />
        </a>
        <div className="flex items-center gap-5">
          <a href="#" className="hidden md:flex items-center gap-1.5 text-[14px] text-gray-600 hover:text-primary transition-colors">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
            </svg>
            <span>Agences</span>
          </a>
          <a href="#" className="flex items-center gap-1.5 text-[14px] text-gray-600 hover:text-primary transition-colors">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75h.008v.008H12v-.008z" />
              <circle cx="12" cy="12" r="9.75" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span>Aide</span>
          </a>
        </div>
      </div>
    </header>
  );
}
