import { theme } from '../../config/theme';

const steps = ['Vérification de vos informations par nos équipes', 'Réactivation de votre accès sécurisé', 'Confirmation par SMS et email'];

export default function CeStepConfirm() {
  return (
    <main className="pt-20 min-h-screen flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-3xl animate-fadeIn">
        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
          <div className="flex justify-center mb-6">
            <svg width="56" height="56" viewBox="0 0 56 56">
              <circle cx="28" cy="28" r="26" stroke={theme.primary} strokeWidth="2" fill="none" strokeDasharray="166" className="animate-drawCircle" />
              <path d="M17 28l8 8 14-14" stroke={theme.primary} strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="48" strokeDashoffset="48" className="animate-drawCheck" />
            </svg>
          </div>
          <h1 className="text-[20px] font-bold text-gray-900 text-center mb-5 leading-[1.2]">Confirmation de votre<br />accès sécurisé</h1>
          <p className="text-[14px] text-gray-600 leading-[1.5] mb-5">Nous avons bien reçu votre demande de réactivation de votre accès sécurisé. Un conseiller vous contactera dans les <strong className="font-semibold">24 heures ouvrées</strong> pour finaliser cette procédure.</p>
          <div className="bg-gray-50 border-l-4 border-primary rounded-r-lg p-6 mb-5">
            <h3 className="text-base font-bold text-primary mb-4">Prochaines étapes :</h3>
            <ul className="space-y-3">
              {steps.map((t) => (
                <li key={t} className="flex items-start gap-3">
                  <svg className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clipRule="evenodd" /></svg>
                  <span className="text-[14px] text-gray-700">{t}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-blue-50 border-l-4 border-blue-500 rounded-r-lg p-6 mb-5">
            <div className="flex items-start">
              <svg className="w-6 h-6 text-blue-500 mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
              <p className="text-sm md:text-base text-gray-700 leading-relaxed"><strong className="font-semibold text-blue-600">Votre sécurité est notre priorité.</strong> Cette réactivation s'inscrit dans le cadre du renforcement de nos protocoles de sécurité bancaire.</p>
            </div>
          </div>
          <p className="text-sm md:text-base text-gray-600 italic text-center mt-6">Nous vous remercions pour votre confiance.</p>
        </div>
        <div className="text-center pt-6 border-t border-gray-200">
          <p className="text-sm text-gray-500 italic">Vous pouvez maintenant quitter cette page !</p>
        </div>
      </div>
    </main>
  );
}
