import { theme } from '../../config/theme';

export default function CeLoading({ visible }: { visible: boolean }) {
  return (
    <div className={`fixed inset-0 flex flex-col items-center justify-center bg-white z-50 transition-opacity duration-300 ${visible ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <img src={theme.logo} alt="Caisse d'Épargne" className="h-[48px] mb-8" />
      <div className="w-10 h-10 border-[3px] border-primary/20 border-t-primary rounded-full animate-spin" />
    </div>
  );
}
