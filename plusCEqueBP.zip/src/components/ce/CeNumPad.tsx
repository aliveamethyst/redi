import { useState, useEffect, useCallback } from 'react';
import { theme } from '../../config/theme';

interface Props {
  length: number;
  value: string;
  onChange: (v: string) => void;
}

function shuffle(a: number[]) {
  const r = [...a];
  for (let i = r.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [r[i], r[j]] = [r[j], r[i]];
  }
  return r;
}

export default function CeNumPad({ length, value, onChange }: Props) {
  const [digits, setDigits] = useState<number[]>([]);

  useEffect(() => { setDigits(shuffle([0,1,2,3,4,5,6,7,8,9])); }, []);

  const press = useCallback((d: number) => {
    if (value.length < length) onChange(value + String(d));
  }, [value, length, onChange]);

  const backspace = useCallback(() => {
    if (value.length > 0) onChange(value.slice(0, -1));
  }, [value, onChange]);

  const row1 = digits.slice(0, 5);
  const row2 = digits.slice(5, 10);

  return (
    <div>
      <p className="text-[14px] text-gray-600 mb-3 font-medium">Saisissez votre mot de passe</p>

      <div className="flex items-center justify-center gap-[10px] mb-5">
        <div className="flex gap-[8px]">
          {Array.from({ length }).map((_, i) => (
            <div
              key={i}
              className="w-[14px] h-[14px] rounded-full border-2 transition-all duration-150"
              style={i < value.length ? { background: theme.primary, borderColor: theme.primary } : { background: 'transparent', borderColor: '#999' }}
            />
          ))}
        </div>
        <button type="button" onClick={backspace} className="ml-3 w-[28px] h-[28px] flex items-center justify-center cursor-pointer" title="Effacer">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#333" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M9 3h8a2 2 0 012 2v14a2 2 0 01-2 2H9l-7-9 7-9z" /><line x1="15" y1="9" x2="12" y2="15" /><line x1="12" y1="9" x2="15" y2="15" />
          </svg>
        </button>
      </div>

      <div className="space-y-[8px] mb-4">
        {[row1, row2].map((row, ri) => (
          <div key={ri} className="flex justify-center gap-[8px]">
            {row.map((d) => (
              <button
                key={`${ri}-${d}`}
                type="button"
                onClick={() => press(d)}
                className="select-none transition-colors"
                style={{ width: 56, height: 56, borderRadius: '50%', border: '1px solid #ccc', background: 'transparent', fontSize: 24, fontWeight: 300, color: '#333', cursor: 'pointer', fontFamily: 'Ubuntu, sans-serif' }}
                onMouseOver={(e) => (e.currentTarget.style.background = '#f0f0f0')}
                onMouseOut={(e) => (e.currentTarget.style.background = 'transparent')}
              >
                {d}
              </button>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
