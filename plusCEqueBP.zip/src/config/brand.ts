/*
 * ====================================
 *  CHANGER LA MARQUE ICI
 * ====================================
 *  'bp' = Banque Populaire
 *  'ce' = Caisse d'Épargne
 */
export const BRAND: 'bp' | 'ce' = 'ce';
